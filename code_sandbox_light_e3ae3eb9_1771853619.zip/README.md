# ImplantAI - Landing Page para Pesquisa de Mercado

## 🎯 Sobre o Projeto

Landing page profissional desenvolvida para validar a viabilidade de mercado de uma solução de IA que identifica marca e modelo de implantes dentários em radiografias odontológicas. O objetivo é capturar o interesse de clínicas de radiologia e coletar dados valiosos sobre o mercado através de uma pesquisa estruturada.

## 📊 Como Visualizar as Respostas da Pesquisa

### **Opção 1: Dashboard Visual (Recomendado)**
Acesse o arquivo `respostas.html` no seu navegador para ver um dashboard completo com:
- ✅ Estatísticas em tempo real (total, hoje, semana, taxa de interesse)
- ✅ Filtros por estado, faixa de preço e busca
- ✅ Cards detalhados com todas as informações de cada resposta
- ✅ Exportação para CSV para análise em Excel
- ✅ Paginação e atualização automática a cada 30 segundos

**URL do Dashboard:** `respostas.html`

### **Opção 2: API REST Direta**
Você pode acessar os dados diretamente através da API:

```javascript
// Listar todas as respostas
GET /tables/survey_responses?limit=100&page=1

// Buscar resposta específica
GET /tables/survey_responses/{id}

// Filtrar por campo
GET /tables/survey_responses?search=clinicName:valor
```

**Exemplo de uso:**
```javascript
fetch('tables/survey_responses?limit=100')
  .then(response => response.json())
  .then(data => {
    console.log('Total de respostas:', data.total);
    console.log('Respostas:', data.data);
  });
```

## 🎨 Design

### Paleta de Cores:
- **Fundo Geral:** Cinza (#d1d5db)
- **Elementos Principais:** Grafite (#3f3f46) - substituindo branco
- **Header/Cards/Formulários:** Grafite escuro (#3f3f46)
- **Textos Primários:** Branco (#ffffff)
- **Textos Secundários:** Cinza claro (#d1d5db)
- **Primary:** Azul (#2563eb)
- **Secondary:** Verde (#10b981)
- **Accent:** Laranja (#f59e0b)
- **Hero Section:** Gradiente roxo

### Logo:
- **Tamanho:** 450px × 120px
- **Posicionamento:** Header e Footer
- **Efeito:** Invertida para branco no fundo escuro

### ✅ Seções da Landing Page

1. **Header com Navegação**
   - Logo e branding da marca "ImplantAI"
   - Menu de navegação responsivo
   - CTA destacado para a pesquisa

2. **Hero Section (Seção Principal)**
   - Proposta de valor clara e impactante
   - Estatísticas de benefícios (90% redução de tempo, 99% precisão, 500+ marcas/modelos)
   - Dois CTAs principais: "Participar da Pesquisa" e "Ver Como Funciona"
   - Elemento visual animado representando a tecnologia

3. **Seção Problema & Solução**
   - Comparativo visual entre os desafios atuais e a solução proposta
   - Layout side-by-side com código de cores diferenciado
   - Lista de pontos negativos vs pontos positivos

4. **Seção de Benefícios**
   - 6 cards destacando os principais benefícios:
     - Velocidade Incomparável
     - Precisão Profissional
     - Aumento de Produtividade
     - Diferencial Competitivo
     - Sempre Atualizado
     - Confiabilidade
   - Ícones personalizados e animações ao scroll

5. **Seção Como Funciona**
   - Processo simplificado em 3 passos
   - Design visual com números e setas indicativas
   - Fácil entendimento do fluxo de uso

6. **Formulário de Pesquisa Completo**
   - **Informações da Clínica:** Nome, contato, cargo, email, telefone, cidade, estado
   - **Sobre o Negócio:** Volume de exames, tempo por exame, método atual, principais dificuldades
   - **Interesse na Solução:** Impacto esperado, disposição a pagar, modelo de cobrança preferido, interesse em trial
   - Campos para sugestões e funcionalidades adicionais
   - Opt-in para newsletter
   - Incentivo destacado: 50% de desconto para participantes

7. **Footer Completo**
   - Informações de marca
   - Links de navegação
   - Informações de contato

### ✅ Recursos Técnicos

- **Design Responsivo:** Funciona perfeitamente em desktop, tablet e mobile
- **Validação de Formulário:** Validação em tempo real com feedback visual
- **Máscaras de Input:** Formatação automática de telefone brasileiro
- **Animações Suaves:** Scroll suave e animações ao entrar na viewport
- **Armazenamento de Dados:** Integração completa com RESTful Table API
- **UX Otimizada:** Mensagens de erro claras, loading states, mensagem de sucesso

## 📊 Dados Coletados pela Pesquisa

### Informações Armazenadas:
- Dados da clínica e contato profissional
- Volume operacional (exames/mês)
- Processos atuais de identificação
- Principais dificuldades enfrentadas
- Percepção de valor da solução
- **Willingness to Pay (WTP):** Faixas de preço aceitas
- Preferência de modelo de negócio
- Interesse em trial gratuito
- Sugestões de funcionalidades
- Autorização para contato futuro

## 🗄️ Estrutura de Banco de Dados

### Tabela: `survey_responses`

A tabela armazena todas as respostas da pesquisa com os seguintes campos:

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | text | Identificador único |
| clinicName | text | Nome da clínica/radiologia |
| contactName | text | Nome do contato |
| role | text | Cargo/função (proprietário, diretor, radiologista, técnico, gerente, outro) |
| email | text | E-mail de contato |
| phone | text | Telefone/WhatsApp |
| city | text | Cidade |
| state | text | Estado (UF) |
| examsPerMonth | text | Quantidade de exames (0-50, 51-100, 101-200, 201-500, 500+) |
| timePerExam | text | Tempo médio por exame (0-2min, 2-5min, 5-10min, 10-15min, 15+min) |
| currentMethod | text | Método atual de identificação |
| mainDifficulty | text | Principal dificuldade |
| impact | text | Impacto esperado da solução |
| pricing | text | Faixa de preço disposto a pagar |
| billingModel | text | Modelo de cobrança preferido |
| trialInterest | text | Interesse em trial gratuito |
| additionalFeatures | rich_text | Funcionalidades adicionais desejadas |
| comments | rich_text | Comentários e sugestões |
| newsletter | bool | Opt-in para newsletter |
| submittedAt | datetime | Data e hora do envio |

### API Endpoints Utilizados:

- **POST** `/tables/survey_responses` - Criar nova resposta de pesquisa
- **GET** `/tables/survey_responses?page=1&limit=100` - Listar respostas (para análise posterior)
- **GET** `/tables/survey_responses/{id}` - Ver resposta específica

## 📁 Estrutura de Arquivos

```
/
├── index.html              # Página principal
├── css/
│   └── style.css          # Estilos personalizados e responsivos
├── js/
│   └── main.js            # Lógica de validação, animações e envio
└── README.md              # Documentação do projeto
```

## 🎨 Design e UX

### Paleta de Cores:
- **Primary:** #2563eb (Azul confiável e profissional)
- **Secondary:** #10b981 (Verde representando solução/sucesso)
- **Accent:** #f59e0b (Laranja para CTAs e destaques)
- **Gradiente Hero:** Purple gradient para impacto visual

### Fontes:
- **Inter** - Fonte moderna, legível e profissional da Google Fonts

### Ícones:
- **Font Awesome** - Biblioteca completa de ícones via CDN

## 🚀 Como Usar

### Visualização Local:
1. Abra o arquivo `index.html` em qualquer navegador moderno
2. A página está totalmente funcional sem necessidade de servidor

### Publicação:
Para publicar e tornar a landing page acessível online, vá até a **aba Publish** e publique o projeto com um clique.

## 📈 Próximos Passos Recomendados

### Curto Prazo:
1. **Adicionar Página de Administração**
   - Dashboard para visualizar respostas da pesquisa
   - Gráficos e análises dos dados coletados
   - Exportação de dados em CSV/Excel

2. **Implementar Analytics**
   - Google Analytics ou similar
   - Rastreamento de conversão
   - Análise de comportamento do usuário

3. **Teste A/B**
   - Testar diferentes headlines
   - Testar diferentes faixas de preço
   - Otimizar taxa de conversão

### Médio Prazo:
1. **Campanhas de Tráfego**
   - Google Ads direcionado para radiologistas
   - LinkedIn Ads para tomadores de decisão
   - Facebook/Instagram Ads

2. **Integração com CRM**
   - Conectar respostas com sistema de CRM
   - Automação de follow-up por email
   - Segmentação de leads por interesse/valor

3. **Conteúdo Adicional**
   - Blog com artigos sobre radiologia
   - Vídeos demonstrativos da tecnologia
   - Casos de uso e depoimentos

### Longo Prazo:
1. **MVP da Solução**
   - Desenvolver versão beta da IA
   - Programa de early adopters
   - Coletar feedback de usuários reais

2. **Expansão**
   - Versão em inglês para mercado internacional
   - Parcerias com fabricantes de implantes
   - Integração com sistemas PACS/RIS

## 🔍 Insights Esperados da Pesquisa

A pesquisa foi estruturada para responder questões críticas de validação:

1. **Tamanho do Mercado:** Quantos exames são processados?
2. **Pain Point Real:** Quanto tempo realmente leva a identificação?
3. **Willingness to Pay:** Quanto o mercado está disposto a pagar?
4. **Modelo de Negócio:** Qual modelo de cobrança prefere?
5. **Barreiras de Adoção:** Há interesse em trial gratuito?
6. **Feature Priority:** Quais funcionalidades são mais importantes?

## 🛡️ Segurança e Privacidade

- Todos os dados são armazenados de forma segura
- Informações usadas apenas para fins de pesquisa
- Possibilidade de implementar LGPD compliance
- Opt-in claro para comunicações futuras

## 📞 Contato

Para dúvidas ou sugestões sobre o projeto:
- **Email:** contato@implantai.com.br
- **Telefone:** (11) 99999-9999

---

**Desenvolvido com foco em validação de mercado e coleta de insights para product-market fit.**