# 🎯 COMANDOS RÁPIDOS - Git e GitHub

## 📋 Opção 1: Upload pela Interface Web (MAIS FÁCIL)

### Passo a Passo Simplificado:

1. **Criar repositório no GitHub:**
   - Acesse: https://github.com/new
   - Nome: `implant-ai`
   - Público
   - Criar repositório

2. **Upload dos arquivos:**
   - Clique em "Add file" > "Upload files"
   - Arraste TODAS as pastas e arquivos
   - Commit changes

3. **Ativar GitHub Pages:**
   - Settings > Pages
   - Source: main branch
   - Salvar

4. **Pronto!** 
   - Seu site estará em: `https://seu-usuario.github.io/implant-ai/`

---

## 💻 Opção 2: Via Git (Linha de Comando)

### Pré-requisitos:
- Git instalado: https://git-scm.com/downloads
- Conta no GitHub criada

### Comandos - Copie e Cole:

```bash
# 1. Navegar até a pasta do projeto
cd caminho/para/implant-ai

# 2. Inicializar Git
git init

# 3. Adicionar todos os arquivos
git add .

# 4. Fazer primeiro commit
git commit -m "Initial commit - Landing page ImplantAI"

# 5. Renomear branch para main
git branch -M main

# 6. Conectar com GitHub (SUBSTITUA SEU-USUARIO)
git remote add origin https://github.com/SEU-USUARIO/implant-ai.git

# 7. Enviar arquivos para GitHub
git push -u origin main
```

### ⚠️ IMPORTANTE:
Substitua `SEU-USUARIO` pelo seu nome de usuário do GitHub!

---

## 🔄 Comandos para Atualizar o Site

Sempre que fizer alterações nos arquivos:

```bash
# 1. Ver o que mudou
git status

# 2. Adicionar alterações
git add .

# 3. Fazer commit com mensagem descritiva
git commit -m "Descrição da alteração"

# 4. Enviar para GitHub
git push
```

**Exemplos de mensagens de commit:**
```bash
git commit -m "Atualizar cores do header"
git commit -m "Adicionar nova seção de depoimentos"
git commit -m "Corrigir bug no formulário"
git commit -m "Atualizar logo e textos"
```

---

## 📁 Estrutura que Deve Ser Enviada

```
implant-ai/
├── index.html
├── respostas.html
├── README.md
├── COMO-VER-RESPOSTAS.md
├── GUIA-GITHUB-PAGES.md
├── css/
│   ├── style.css
│   └── force-colors.css
├── js/
│   └── main.js
└── images/
    ├── logo-implantai.png
    └── logo-implantai-dark.png
```

---

## 🌐 Ativar GitHub Pages

### Via Interface Web:
1. Vá em: `https://github.com/SEU-USUARIO/implant-ai/settings/pages`
2. Em "Source" selecione: **main** branch
3. Clique em **Save**
4. Aguarde 1-2 minutos

### Confirmar que está funcionando:
Acesse: `https://SEU-USUARIO.github.io/implant-ai/`

---

## 🔗 URLs do Seu Site

Após publicar, você terá:

**Landing Page:**
```
https://SEU-USUARIO.github.io/implant-ai/
```

**Dashboard de Respostas:**
```
https://SEU-USUARIO.github.io/implant-ai/respostas.html
```

**Guia de Como Ver Respostas:**
```
https://SEU-USUARIO.github.io/implant-ai/COMO-VER-RESPOSTAS.md
```

---

## 🚨 Solução de Problemas Rápida

### Erro: "Permission denied"
```bash
# Configure suas credenciais
git config --global user.name "Seu Nome"
git config --global user.email "seu@email.com"
```

### Erro: "Repository not found"
Verifique se:
1. O repositório foi criado no GitHub
2. A URL está correta (com seu usuário)
3. Você está logado no GitHub

### Site não aparece (404)
1. Verifique se GitHub Pages está ativado
2. Aguarde 2-3 minutos
3. Recarregue a página (Ctrl + F5)
4. Certifique-se que o arquivo se chama `index.html`

### Imagens não aparecem
```bash
# Verificar se os arquivos foram enviados
git ls-files images/

# Se não aparecer nada, envie novamente:
git add images/
git commit -m "Adicionar imagens"
git push
```

---

## 📱 GitHub Desktop (Alternativa Gráfica)

Se você prefere interface gráfica:

1. **Baixe:** https://desktop.github.com
2. **Instale** e faça login
3. **File** > **Add Local Repository**
4. Selecione a pasta `implant-ai`
5. **Publish repository** para enviar ao GitHub
6. Ative GitHub Pages nas configurações

---

## ✅ Checklist Antes de Publicar

- [ ] Todos os arquivos estão na pasta correta
- [ ] Git está instalado (`git --version` para testar)
- [ ] Repositório criado no GitHub
- [ ] Arquivos foram commitados (`git status` para verificar)
- [ ] Push foi feito com sucesso
- [ ] GitHub Pages foi ativado
- [ ] Aguardou 2-3 minutos
- [ ] Testou a URL no navegador

---

## 🎓 Comandos Git Úteis

```bash
# Ver status dos arquivos
git status

# Ver histórico de commits
git log --oneline

# Desfazer última alteração (antes do commit)
git checkout -- nome-do-arquivo.html

# Ver diferenças
git diff

# Criar uma branch para testar
git checkout -b teste

# Voltar para main
git checkout main

# Puxar atualizações (se trabalhar em equipe)
git pull

# Clonar repositório em outro computador
git clone https://github.com/SEU-USUARIO/implant-ai.git
```

---

## 🎯 Fluxo de Trabalho Recomendado

1. **Editar localmente** no seu computador
2. **Testar** abrindo `index.html` no navegador
3. **Commitar** as alterações com `git add .` e `git commit`
4. **Enviar** com `git push`
5. **Aguardar** 1-2 minutos
6. **Verificar** no site online

---

## 💡 Dicas Finais

### Para Iniciantes:
- Use a **interface web** do GitHub (mais simples)
- Faça um arquivo por vez no começo
- Sempre teste localmente antes de fazer push

### Para Intermediários:
- Use **branches** para testar mudanças grandes
- Configure **GitHub Desktop** para facilitar
- Aprenda comandos Git básicos

### Para Avançados:
- Configure **GitHub Actions** para CI/CD
- Use **pre-commit hooks** para validação
- Configure **custom domain** com HTTPS

---

## 📚 Recursos de Aprendizado

**Git Básico:**
- https://git-scm.com/book/pt-br/v2
- YouTube: "Git e GitHub para Iniciantes"

**GitHub Pages:**
- https://pages.github.com
- https://docs.github.com/pt/pages

**Markdown (para README):**
- https://www.markdownguide.org/basic-syntax/

---

## 🆘 Comandos de Emergência

```bash
# Se algo deu muito errado e quer recomeçar:
cd ..
rm -rf implant-ai
git clone https://github.com/SEU-USUARIO/implant-ai.git
cd implant-ai

# Forçar push (USE COM CUIDADO!)
git push -f origin main

# Reverter último commit
git revert HEAD

# Ver configuração do repositório remoto
git remote -v
```

---

**🎉 Pronto! Com estes comandos você consegue publicar e gerenciar seu site!**

**Lembre-se:** A forma mais fácil é usar a interface web do GitHub. 
Os comandos Git são para quem quer mais controle e trabalhar localmente.

**Boa sorte! 🚀**