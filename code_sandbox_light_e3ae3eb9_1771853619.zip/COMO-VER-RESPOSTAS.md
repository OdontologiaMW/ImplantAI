# 📋 COMO VISUALIZAR AS RESPOSTAS DA PESQUISA

## 🎯 Método Mais Fácil: Dashboard Visual

1. **Abra o arquivo `respostas.html` no seu navegador**
   - Clique duas vezes no arquivo `respostas.html`
   - OU arraste o arquivo para o navegador
   - OU acesse via URL: `seu-dominio.com/respostas.html`

2. **O que você verá:**
   - 📊 Estatísticas em tempo real
   - 🔍 Filtros de busca por nome, email, cidade
   - 🗺️ Filtro por estado
   - 💰 Filtro por faixa de preço
   - 📥 Botão para exportar tudo para Excel (CSV)
   - 🔄 Atualização automática a cada 30 segundos

3. **Funcionalidades do Dashboard:**
   - **Buscar:** Digite qualquer informação no campo de busca
   - **Filtrar:** Use os dropdowns para filtrar por estado ou preço
   - **Exportar:** Clique em "Exportar CSV" para baixar os dados
   - **Navegar:** Use os botões de página para ver todas as respostas

## 🔗 URLs Importantes

### Landing Page (para compartilhar com clientes):
```
index.html
```

### Dashboard de Respostas (para você analisar):
```
respostas.html
```

## 📊 O Que Cada Resposta Contém

1. **Informações da Clínica:**
   - Nome da clínica
   - Nome do contato
   - Cargo/função
   - Email
   - Telefone/WhatsApp
   - Cidade e Estado

2. **Perfil Operacional:**
   - Quantos exames com implantes por mês
   - Tempo médio gasto por exame
   - Método atual de identificação
   - Principal dificuldade enfrentada

3. **Interesse Comercial:**
   - Impacto esperado da solução
   - Quanto está disposto a pagar
   - Modelo de cobrança preferido
   - Interesse em teste gratuito de 30 dias

4. **Feedback Qualitativo:**
   - Funcionalidades adicionais desejadas
   - Comentários e sugestões

## 💡 Dicas de Análise

### Para Identificar Hot Leads:
1. Filtre por preço: R$ 201+ (maior disposição a pagar)
2. Busque por "transformador" ou "muito-positivo" no impacto
3. Olhe quem tem mais de 100 exames/mês
4. Priorize quem respondeu "sim-definitivamente" para trial

### Para Análise de Mercado:
1. Exporte para CSV
2. Abra no Excel/Google Sheets
3. Crie tabelas dinâmicas para:
   - Distribuição geográfica (por estado)
   - Faixas de preço aceitas
   - Volume de exames por região
   - Principais dificuldades mencionadas

## 🚀 Acesso via API (Avançado)

Se você quiser integrar com outras ferramentas:

```javascript
// JavaScript exemplo
fetch('tables/survey_responses?limit=100')
  .then(r => r.json())
  .then(data => console.log(data))
```

**Endpoints disponíveis:**
- `GET /tables/survey_responses` - Lista todas
- `GET /tables/survey_responses?page=1&limit=10` - Com paginação
- `GET /tables/survey_responses/{id}` - Resposta específica

## 📞 Suporte

Se tiver dúvidas sobre como acessar ou analisar os dados, entre em contato!

---

**🎉 Boa sorte com sua validação de mercado!**