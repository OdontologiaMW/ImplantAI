// Smooth scroll para links de navegação
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Validação e envio do formulário
const surveyForm = document.getElementById('surveyForm');
const successMessage = document.getElementById('successMessage');

surveyForm.addEventListener('submit', async function(e) {
    e.preventDefault();

    // Validação customizada
    if (!validateForm()) {
        return;
    }

    // Coletar dados do formulário
    const formData = new FormData(surveyForm);
    const data = {};

    // Converter FormData para objeto
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }

    // Adicionar timestamp
    data.submittedAt = new Date().toISOString();

    try {
        // Desabilitar botão de envio
        const submitButton = surveyForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';

        // Enviar para a API
        const response = await fetch('tables/survey_responses', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            // Mostrar mensagem de sucesso
            surveyForm.style.display = 'none';
            successMessage.style.display = 'block';
            
            // Scroll para a mensagem de sucesso
            successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });

            // Opcional: enviar evento de conversão para analytics
            if (typeof gtag !== 'undefined') {
                gtag('event', 'form_submission', {
                    'event_category': 'engagement',
                    'event_label': 'survey_completed'
                });
            }
        } else {
            throw new Error('Erro ao enviar formulário');
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Ocorreu um erro ao enviar sua pesquisa. Por favor, tente novamente ou entre em contato conosco.');
        
        // Reabilitar botão
        const submitButton = surveyForm.querySelector('button[type="submit"]');
        submitButton.disabled = false;
        submitButton.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar Pesquisa';
    }
});

// Função de validação customizada
function validateForm() {
    const requiredFields = surveyForm.querySelectorAll('[required]');
    let isValid = true;

    requiredFields.forEach(field => {
        if (field.type === 'radio') {
            const radioGroup = surveyForm.querySelectorAll(`[name="${field.name}"]`);
            const isChecked = Array.from(radioGroup).some(radio => radio.checked);
            
            if (!isChecked) {
                isValid = false;
                highlightError(field.closest('.form-group'));
            } else {
                removeError(field.closest('.form-group'));
            }
        } else {
            if (!field.value.trim()) {
                isValid = false;
                highlightError(field.closest('.form-group'));
            } else {
                removeError(field.closest('.form-group'));
            }
        }
    });

    // Validação de email
    const emailField = document.getElementById('email');
    if (emailField.value && !isValidEmail(emailField.value)) {
        isValid = false;
        highlightError(emailField.closest('.form-group'), 'Por favor, insira um e-mail válido');
    }

    // Validação de telefone
    const phoneField = document.getElementById('phone');
    if (phoneField.value && !isValidPhone(phoneField.value)) {
        isValid = false;
        highlightError(phoneField.closest('.form-group'), 'Por favor, insira um telefone válido');
    }

    if (!isValid) {
        // Scroll para o primeiro campo com erro
        const firstError = surveyForm.querySelector('.form-group.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    return isValid;
}

// Função para destacar erro
function highlightError(formGroup, message = 'Este campo é obrigatório') {
    if (!formGroup) return;
    
    formGroup.classList.add('error');
    
    // Remover mensagem de erro anterior se existir
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Adicionar mensagem de erro
    const errorMessage = document.createElement('div');
    errorMessage.className = 'error-message';
    errorMessage.textContent = message;
    errorMessage.style.color = 'var(--error-color)';
    errorMessage.style.fontSize = '0.875rem';
    errorMessage.style.marginTop = '0.25rem';
    formGroup.appendChild(errorMessage);
}

// Função para remover erro
function removeError(formGroup) {
    if (!formGroup) return;
    
    formGroup.classList.remove('error');
    const errorMessage = formGroup.querySelector('.error-message');
    if (errorMessage) {
        errorMessage.remove();
    }
}

// Validação de email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validação de telefone (formato brasileiro)
function isValidPhone(phone) {
    const phoneRegex = /^(\(?\d{2}\)?\s?)?(\d{4,5}-?\d{4})$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// Máscara de telefone
const phoneInput = document.getElementById('phone');
if (phoneInput) {
    phoneInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        
        if (value.length <= 11) {
            if (value.length <= 10) {
                // (00) 0000-0000
                value = value.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, '($1) $2-$3');
            } else {
                // (00) 00000-0000
                value = value.replace(/^(\d{2})(\d{5})(\d{0,4}).*/, '($1) $2-$3');
            }
        }
        
        e.target.value = value;
    });
}

// Remover erros quando o usuário começar a digitar
const allInputs = surveyForm.querySelectorAll('input, select, textarea');
allInputs.forEach(input => {
    input.addEventListener('input', function() {
        const formGroup = this.closest('.form-group');
        if (formGroup && formGroup.classList.contains('error')) {
            removeError(formGroup);
        }
    });

    input.addEventListener('change', function() {
        const formGroup = this.closest('.form-group');
        if (formGroup && formGroup.classList.contains('error')) {
            removeError(formGroup);
        }
    });
});

// Animação de entrada dos elementos
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Aplicar animação aos elementos
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.benefit-card, .step, .form-section');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Rastreamento de interação (opcional - para analytics)
function trackInteraction(action, label) {
    if (typeof gtag !== 'undefined') {
        gtag('event', action, {
            'event_category': 'user_interaction',
            'event_label': label
        });
    }
}

// Rastrear cliques nos CTAs
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function() {
        const buttonText = this.textContent.trim();
        trackInteraction('button_click', buttonText);
    });
});

// Rastrear scroll depth
let maxScrollDepth = 0;
window.addEventListener('scroll', function() {
    const scrollDepth = Math.round((window.scrollY + window.innerHeight) / document.documentElement.scrollHeight * 100);
    
    if (scrollDepth > maxScrollDepth) {
        maxScrollDepth = scrollDepth;
        
        if (maxScrollDepth >= 25 && maxScrollDepth < 50) {
            trackInteraction('scroll_depth', '25%');
        } else if (maxScrollDepth >= 50 && maxScrollDepth < 75) {
            trackInteraction('scroll_depth', '50%');
        } else if (maxScrollDepth >= 75 && maxScrollDepth < 90) {
            trackInteraction('scroll_depth', '75%');
        } else if (maxScrollDepth >= 90) {
            trackInteraction('scroll_depth', '90%');
        }
    }
});